import ViewPropTypes from './viewPropTypes'

export { ViewPropTypes }