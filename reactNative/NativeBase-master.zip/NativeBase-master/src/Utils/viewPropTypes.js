import { ViewPropTypes as RNViewPropTypes, View } from 'react-native'

const ViewPropTypes = RNViewPropTypes || View.propTypes

export default ViewPropTypes