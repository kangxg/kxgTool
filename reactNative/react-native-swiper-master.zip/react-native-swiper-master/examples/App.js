import { AppRegistry } from 'react-native'
import Basic from './components/Basic/'
// import Dynamic from './components/Dynamic/'
// import LoadMinimal from './components/LoadMinimal/'
// import Phone from './components/Phone/'
// import PhotoView from './components/PhotoView/' // not working
// import Swiper from './components/Swiper/'  // working but no title displayed
// import SwiperNumber from './components/SwiperNumber/' // working but no title displayed
AppRegistry.registerComponent('examples', () => Basic);
